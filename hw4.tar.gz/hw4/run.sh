#!/usr/bin/env bash

# A script that invokes your compiler.
./compiler.jar $@ <&0 >&1
