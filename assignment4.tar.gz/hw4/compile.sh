#!/usr/bin/env bash

# A script that builds your compiler.
